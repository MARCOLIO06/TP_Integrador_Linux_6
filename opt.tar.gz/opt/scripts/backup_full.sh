#!/bin/bash

#opcion de ayuda

if [[$1 == "-help"]]; then
echo "Uso: backup_full.sh <origen><destino>"
echo "Ejemplo: ./backup_full.sh /var/log /backup_dir"
exit 0
fi

#validar argumentos

if [[$# -ne 2 ]]; then
echo "Error: ingrese origen y destino"
exit 1
fi

#variables

ORIGEN=$1
DESTINO=$2
FECHA=(date +%Y%m%d)
NOMBRE=$(basename $ORIGEN)

#validar que origen y destino existen

if [[! -d $ORIGEN ]]; then
echo "El origen no existe"
exit 1
fi

if [[! -d $DESTINO ]]; then
echo "El destino no existe"
exit 1
fi

tar -czf $DESTINO/${NOMBRE}_BKP_${FECHA}.tar.gz $ORIGEN
echo "Backup realizado: ${NOMBRE}_bkp_${FECHA}.tar.gz|"


#ejecutar backup

